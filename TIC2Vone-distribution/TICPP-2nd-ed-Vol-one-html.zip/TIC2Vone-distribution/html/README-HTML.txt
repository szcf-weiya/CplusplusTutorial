README-HTML.txt file for Thinking in C++, 2nd Edition, Volume 1
Copyright (c)2000 by Bruce Eckel www.BruceEckel.com

This set of HTML files is designed to work with most web browsers. 
You will find here the entire book, "Thinking in C++ 2nd edition, Volume 1."
Volume 2 can be found at http://www.BruceEckel.com

Please note:

-- To start using the frames version, open:
    >> "Frames.html" for the abbreviated table of contents
    >> "Frames-expanded-TOC.html" for the full table of contents
    
-- To start using non-frames versions, open:
    >> Any of the "Chapter??.html" files directly; navigation is built-in
    >> "Contents.html" for the full table of contents
    >> "SimpleContents.html" for just the Chapter titles in the table of contents
    >> "DocIndex.html" to open the index
    
-- Remember that when you click on links within the document, you can 
   always use your browser's "back" arrow to return to where you 
   were reading.

-- If you're viewing this on Netscape under Linux, try going to 
   View|Character Set and selecting "Western (ISO-8859-15).
   
-- The document uses fonts which you may want to download:
   http://www.microsoft.com/typography/downloads/georgi32.exe (Georgia for Win9X)
   http://www.microsoft.com/typography/downloads/georgia.exe (Georgia Win 3.1)
   http://www.microsoft.com/typography/downloads/Georgia.sit.hqx (Georgia Mac)
   http://www.microsoft.com/typography/downloads/verdan32.exe (verdana Win 9X) 
   http://www.microsoft.com/typography/downloads/verdana.exe (verdana Win 3.1) 
   http://www.microsoft.com/typography/downloads/Verdana.sit.hqx (verdana Mac)

